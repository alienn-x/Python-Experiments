import os

#Making Directories

os.makedirs("C:\\Exercise Logger\\DietLog")
os.makedirs("C:\\Exercise Logger\\ExLog")