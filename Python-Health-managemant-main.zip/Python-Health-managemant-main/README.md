# Python-Health-managemant
This is a mini project <br>
Run setup.py <br>
Then you can run main.py <br>

THis will work on windows only <br>
Program data path : C:/Exercise Logger <br>
This programme uses predefined names, Dont worry i'll make it use your name<br>
Final changes - Now this can use your name

